int main(void)
{
    int v = 0;
    for (int i = 0; i < 10; i++)
    {
        v += i;
    }
    return v;
}
