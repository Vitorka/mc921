import org.antlr.v4.runtime.tree.pattern.ParseTreePatternMatcher;

import java.util.*;

public class Semantic extends GrammarBaseVisitor<String> {

    //Number of local variables used in a func
    int localID = 1;

    //List with all params of a func
    List<String> funcParams = new ArrayList<String>();

    //List with all local variables
    List<String> localVariables = new ArrayList<String>();

    //Hashmap with all the global variables and its initializer functions
    Map<String, String> globalVariables = new LinkedHashMap<String, String>();

    @Override public String visitRootComponent(GrammarParser.RootComponentContext ctx) {
        visit(ctx.component());

        //Print the global initializer function for variables
        System.out.println("define void @" + "initializer" + "() {");
        Iterator funcs = globalVariables.entrySet().iterator();
        while (funcs.hasNext()) {
            Map.Entry element = (Map.Entry)funcs.next();
            System.out.println("    " + "call void @" + element.getValue() + "()");
        }
        System.out.println("    " + "ret void");
        System.out.println("}");
        return null;
    }

    @Override public String visitComponentVar(GrammarParser.ComponentVarContext ctx) {
        visit(ctx.var());
        return null;
    }

    @Override public String visitComponentComponent(GrammarParser.ComponentComponentContext ctx) {
        visit(ctx.component(0));
        visit(ctx.component(1));
        return null;
    }

    @Override public String visitComponentFunc(GrammarParser.ComponentFuncContext ctx) {
        visit(ctx.func());
        return null;
    }

    @Override public String visitVar(GrammarParser.VarContext ctx) {

        //Add the initialize function of the variable inside the list to make the global initializer function after
        globalVariables.put(ctx.ID().toString(), ctx.ID().toString() + "_initializer");

        //Print the declaration of the variable and its initializer function
        System.out.println("@" + ctx.ID().toString() + " = global i32 0;");
        System.out.println("define void @" + ctx.ID().toString() + "_initializer" + "() {");

        //Visit the expression of the variable
        String lastVariable = visit(ctx.expr());

        //Print the store of the value of the variable
        System.out.println("    " + "store i32 " + lastVariable + ", i32* @" + ctx.ID().toString());
        System.out.println("    " + "ret void");
        System.out.println("}");

        localVariables = new ArrayList<String>();
        localID = 1;

        return null;
    }

    @Override public String visitFunc(GrammarParser.FuncContext ctx) {

        //Get all the params of the function, put them in a list of local variables and then transform them in a string
        visit(ctx.params());
        localVariables = new ArrayList<String>(funcParams);
        String params = "";
        for (String i : funcParams) {
            params += "i32 " + i + ", ";
        }

        //Print all operations inside a function
        System.out.println("define i32 @" + ctx.ID().toString() + "(" + params.substring(0, params.length() - 2) + ") {");

        //Visit the expression of the function
        String lastVariable = visit(ctx.expr());

        //Print the return of the de function, which is the last variable declared inside the function
        System.out.println("    " + "ret i32 " + lastVariable);
        System.out.println("}");

        funcParams = new ArrayList<String>();
        localVariables = new ArrayList<String>();
        localID = 1;

        return null;
    }

    //Function that construct all the expressions in the program
    private String solveExpressions(String leftExpr, String rightExpr, String operation) {

        //leftExpr is a local variable or number and rightExpr is a local variable or number
        if((localVariables.contains(leftExpr) || leftExpr.matches("[0-9]+")) &&
                (localVariables.contains(rightExpr) || rightExpr.matches("[0-9]+"))) {
            System.out.println("    %" + localID + " = " + operation + " i32 " + leftExpr + ", " + rightExpr);
            localVariables.add("%" + localID);
        }
        //leftExpr is a local variable or number and rightExpr is a local variable
        else if(localVariables.contains(rightExpr) && (localVariables.contains(leftExpr) || leftExpr.matches("[0-9]+"))) {
            System.out.println("    %" + localID + " = " + operation + " i32 " + leftExpr + ", " + rightExpr);
            localVariables.add("%" + localID);
        }
        //leftExpr is a local variable or number and rightExpr is a global variable
        else if ((localVariables.contains(leftExpr) || leftExpr.matches("[0-9]+")) && globalVariables.containsKey(rightExpr.substring(1))) {
            System.out.println("    %" + localID + " = " + "load i32, i32* @" + rightExpr.substring(1));
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + operation + " i32 " + leftExpr + ", " + "%" + (localID - 1));
            localVariables.add("%" + localID);
        }
        //leftExpr is a global variable and rightExpr is a local variable or number
        else if ((localVariables.contains(rightExpr) || rightExpr.matches("[0-9]+")) && globalVariables.containsKey(leftExpr.substring(1))) {
            System.out.println("    %" + localID + " = " + "load i32, i32* @" + leftExpr.substring(1));
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + operation + " i32 " + "%" + (localID - 1) + ", " + rightExpr);
            localVariables.add("%" + localID);
        }
        //leftExpr and rightExpr are global variables
        else if (globalVariables.containsKey(leftExpr.substring(1)) && globalVariables.containsKey(rightExpr.substring(1))) {
            System.out.println("    %" + localID + " = " + "load i32, i32* @" + leftExpr.substring(1));
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + "load i32, i32* @" + rightExpr.substring(1));
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + operation + " i32 " + "%" + (localID - 2) + ", " + "%" + (localID - 1));
            localVariables.add("%" + localID);
        }
        //leftExpr and rightExpr are functions
        else if(Character.compare(leftExpr.charAt(0), '@') == 0 && Character.compare(rightExpr.charAt(0), '@') == 0) {
            System.out.println("    %" + localID + " = " + "call i32 " + leftExpr);
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + "call i32 " + rightExpr);
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + operation + " i32 " + "%" + (localID - 2) + ", " + "%" + (localID - 1));
            localVariables.add("%" + localID);
        }
        //leftExpr is a local variable or number and rightExpr is a function
        else if((localVariables.contains(leftExpr) || leftExpr.matches("[0-9]+")) && Character.compare(rightExpr.charAt(0), '@') == 0) {
            System.out.println("    %" + localID + " = " + "call i32 " + rightExpr);
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + operation + " i32 " + leftExpr + ", " + "%" + (localID - 1));
            localVariables.add("%" + localID);
        }
        //leftExpr is a global variable and rightExpr is a function
        else if(globalVariables.containsKey(leftExpr.substring(1)) && Character.compare(rightExpr.charAt(0), '@') == 0) {
            System.out.println("    %" + localID + " = " + "load i32, i32* @" + leftExpr.substring(1));
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + "call i32 " + rightExpr);
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + operation + " i32 " + "%" + (localID - 2) + ", " + "%" + (localID - 1));
            localVariables.add("%" + localID);
        }
        //leftExpr is a function and rightExpr is a local variable or number
        else if((localVariables.contains(rightExpr) || rightExpr.matches("[0-9]+")) && Character.compare(leftExpr.charAt(0), '@') == 0) {
            System.out.println("    %" + localID + " = " + "call i32 " + leftExpr);
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + operation + " i32 " + "%" + (localID - 1) + ", " + rightExpr);
            localVariables.add("%" + localID);
        }
        //leftExpr is a function and rightExpr is a global variable
        else if(globalVariables.containsKey(rightExpr.substring(1)) && Character.compare(leftExpr.charAt(0), '@') == 0) {
            System.out.println("    %" + localID + " = " + "call i32 " + leftExpr);
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + "load i32, i32* @" + rightExpr.substring(1));
            localVariables.add("%" + localID++);
            System.out.println("    %" + localID + " = " + operation + " i32 " + "%" + (localID - 2) + ", " + "%" + (localID - 1));
            localVariables.add("%" + localID);
        }
        return "%" + localID++;
    }

    @Override public String visitExprSum(GrammarParser.ExprSumContext ctx) {
        return solveExpressions(visit(ctx.expr()), visit(ctx.prior()), "add");
    }

    @Override public String visitExprMinus(GrammarParser.ExprMinusContext ctx) {
        return solveExpressions(visit(ctx.expr()), visit(ctx.prior()), "sub");
    }

    @Override public String visitExprPrior(GrammarParser.ExprPriorContext ctx) {
        String prior = visit(ctx.prior());

        //If prior is a local variable
        if(localVariables.contains(prior)) {
            localVariables.add("%" + prior);
            return prior;
        }
        //If prior is a number
        if(prior.matches("[0-9]+")) {
            return prior;
        }
        //If prior is a global variable
        else if(globalVariables.containsKey(prior.substring(1))) {
            System.out.println("    %" + localID + " = " + "load i32, i32* @" + prior.substring(1));
            localVariables.add("%" + localID);
            return "%" + localID++;
        }
        //If prior is a function
        else {
            System.out.println("    %" + localID + " = " + "call i32 " + prior);
            localVariables.add("%" + localID);
            return "%" + localID++;
        }
    }

    @Override public String visitPriorDiv(GrammarParser.PriorDivContext ctx) {
        return solveExpressions(visit(ctx.prior()), visit(ctx.terminal()), "sdiv");
    }

    @Override public String visitPriorMult(GrammarParser.PriorMultContext ctx) {
        return solveExpressions(visit(ctx.prior()), visit(ctx.terminal()), "mul");
    }

    @Override public String visitPriorTerminal(GrammarParser.PriorTerminalContext ctx) {
        return visit(ctx.terminal());
    }

    @Override public String visitTerminalFunc(GrammarParser.TerminalFuncContext ctx) {
        return "@" + ctx.ID().toString() + "(" + visit(ctx.exprparams()) + ")";
    }

    @Override public String visitTerminalNum(GrammarParser.TerminalNumContext ctx) {
        return ctx.NUM().toString();
    }

    @Override public String visitTerminalID(GrammarParser.TerminalIDContext ctx) {
        return "%" + ctx.ID().toString();
    }

    @Override public String visitTerminalParen(GrammarParser.TerminalParenContext ctx) {
        return visit(ctx.expr());
    }

    @Override public String visitParamsID(GrammarParser.ParamsIDContext ctx) {
        funcParams.add("%" + ctx.ID().toString());
        return null;
    }

    @Override public String visitVariousParams(GrammarParser.VariousParamsContext ctx) {
        visit(ctx.params(0));
        visit(ctx.params(1));
        return null;
    }

    @Override public String visitExprParamsNUM(GrammarParser.ExprParamsNUMContext ctx) {
        return "i32 " + ctx.NUM().toString();
    }

    @Override public String visitExprParamsID(GrammarParser.ExprParamsIDContext ctx) {

        //If the ID is a local variable
        if(localVariables.contains("%" + ctx.ID().toString())) {
            return "i32 %" + ctx.ID().toString();
        }
        //If the ID is a global variable
        else {
            System.out.println("    %" + localID + " = " + "load i32, i32* @" + ctx.ID().toString());
            return "i32 %" + localID++;
        }
    }

    @Override public String visitVariousExprParams(GrammarParser.VariousExprParamsContext ctx) {
        return visit(ctx.exprparams(0)) + ", " + visit(ctx.exprparams(1));
    }
}
