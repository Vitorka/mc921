var x = 30
var y = 50

func jon(a, b) : ((a * b) + 5)
func jen(a, b) : ((a + x) + (b * y))
func a(var1) : (jon(var1, x) - y)
func func1(func1, var1) :
(
    (func1 / var1) +
    (
        ((x + func1) / jen(func1, a(func1))) *
        (jon(x, y) - 42)
    )
)
