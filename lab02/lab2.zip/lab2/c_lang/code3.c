INT 	LONG +,-*>ENUM VOID UNION&:
0x123Ff||44465.1234&&9632 '5'_aboko
 	 INT990 )) _aA8Aa_ { ][	;
#
