// this is a comment

INT function(CHAR *a)
{
	*a = '5';
	RETURN 56;
}

FLOAT banana(VOID)
{
	RETURN 9.46;
}

CHAR str[] = "STRING";

INT main()
{
	CHAR lf = '\n';
	RETURN 0x002;
}
