// this is a comment

int function(char *a)
{
	*a = '5';
	return 56;
}

float banana(void)
{
	return 9.46;
}

char str[] = "STRING";

int main()
{
	char lf = '\n';
	return 0x002;
}
