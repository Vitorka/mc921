#!/bin/bash
java -jar "antlr-4.7.2-complete.jar" -no-listener -visitor Grammar.g4
export CLASSPATH=".:antlr-4.7.2-complete.jar:$CLASSPATH"
javac *.java
java MyParser < test$1.sm > result$1.txt
java org.antlr.v4.gui.TestRig Grammar root -gui < test7.sm
